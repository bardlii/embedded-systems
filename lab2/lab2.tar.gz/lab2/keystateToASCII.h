#ifndef _KEYSTATETOASCII_H
#define _KEYSTATETOASCII_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* keystateToASCII(const char *keystate);

#endif